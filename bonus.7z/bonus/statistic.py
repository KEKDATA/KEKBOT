from SPARQLWrapper import JSON
import time
import sparql as sp

# ===============================================================
#								ЧЕРНОВОЙ ВАРИАНТ СТАТИСТИКИ
# ===============================================================

QUERY_GET_FIRM_BY_REGION = """
PREFIX fts: <https://w3id.org/datafabric.cc/ontologies/fts#> 
SELECT DISTINCT ?ogrn{{ 

?le a fts:C9_Legal_Entity.

?le fts:p28_le_primary_state_registration_number ?ogrn.

?addrE a fts:C39_Address_Entity; 
    fts:p82_refers_to_company ?le;
    fts:p98_located_at ?reg.

?reg a fts:C96_Region_Element;
     fts:p19_region_code ?region_code.

BIND("{rg_cd}" AS ?region_code)
}}
"""

QUERY_GET_REGION_CODES = """
PREFIX foaf: <http://xmlns.com/foaf/0.1/> 
PREFIX fts: <https://w3id.org/datafabric.cc/ontologies/fts#> 
SELECT ?region_code
WHERE {{
?region_entity a fts:C96_Region_Element;
    fts:p25_element_type ?region_type;
    fts:p19_region_code ?region_code;
    fts:p6_name ?region_name.
}}
"""

QUERY_GET_FIRM_BY_REGION1 = """
PREFIX fts: <https://w3id.org/datafabric.cc/ontologies/fts#> 
SELECT DISTINCT ?le ?region_code
WHERE {{
?le a fts:C9_Legal_Entity.

?addrE a fts:C39_Address_Entity; 
		 fts:p82_refers_to_company ?le;
		 fts:p98_located_at ?t.

?t a fts:C96_Region_Element;
	 fts:p19_region_code ?region_code.
	 
BIND("77" AS ?region_code)
}}
"""

QUERY_TEST_FORMS = """
PREFIX fts: <https://w3id.org/datafabric.cc/ontologies/fts#> 
SELECT DISTINCT ?shortName{{ 

?le a fts:C9_Legal_Entity.

  ?nameE a fts:C38_Name_Entity ;
         fts:p82_refers_to_company ?le ;

         fts:p17_short_name ?shortName .

 FILTER(STRSTARTS(?shortName, "{sct}")).
}}
"""

QUERY_GET_SHORTCUTS_AMOUNT = """
PREFIX fts: <https://w3id.org/datafabric.cc/ontologies/fts#> 
SELECT DISTINCT ?item (count(?shortName) as ?namecount){{

?le a fts:C9_Legal_Entity.

  ?nameE a fts:C38_Name_Entity ;
         fts:p82_refers_to_company ?le ;

         fts:p17_short_name ?shortName .

 FILTER(STRSTARTS(?shortName, "{sct}")).
}} GROUP BY ?item
"""
# ==================================================================================


def timer(f):
    """
    :param      f:  Some function

    :return:    func obj

    Just for benchmark.
    """
    def tmp(*args, **kwargs):
        t = time.time()
        res = f(*args, **kwargs)
        print("Время выполнения функции: %f" % (time.time()-t))
        return res
    return tmp


@timer
def test(sparql_param):
    """
    :param      sparql_param:   SPARQL endpoint

    :return:    None

    Tests the time of executing get_shortcuts function for all shortcuts.

    Executed in 21 minutes.
    """
    shortcuts_list = [
              "АНО ", "АУ ", "АТП ", "АП ", "АО ", "АС ", "БФ ", "БСП ", "БУ ", "ВБФ ", "ГСК ", "ГК ", "ГБУ ", "ГКУ ",
              "ГП ", "ГУП ", "Д/С ", "ЖСК ", "ЗАО ", "КЛХ ", "КФ ", "КЦ ", "КБ ", "КООП ", "КС ", "КФХ ", "КХ ", "МП ",
              "МСЧ ", "МХП ", "МУП ", "МКП ", "МКУ ", "МБУ ", "НПФ ", "НПО ", "НПП ", "НТЦ ", "НП ", "НОТК ", "ОСП",
              "ОО ", "ОД ", "ОФ ", "ОДО ", "ООО ", "ОП ", "ОТ ", "ОАО ", "ППО ", "ПТ ", "ПТК ", "ПС ", "ПОО ",
              "ПРЕД ", "ПО ", "ПКК ", "ПКФ ", "ПКП ", "ПК ", "ПРОФКОМ ", "РО ", "РОБ ", "РСУ ", "РЭУ ", "СТ ", "СХК ",
              "СХПК ", "СЕМ ", "СМТ ", "СП ", "Союз ", "СКБ ", "СМУ ", "СТП", "ТОС ", "ТВ ", "ТСЖ ", "ТФ ", "ТПП ",
              "ТД ", "ТФПГ ", "УПТК ", "УОО ", "ФГУП ", "ФКП ", "ФБУ ", "ФГУ ", "ФГБУ ", "ФКУ ", "ФЛ ", "ФФ ", "ФИК ",
              "ФПГ ", "Фирма ", "Фонд ", "ХОЗУ ", "ЧОП ", "ЧУ ", "ЧИФ "
              ]
    keys = [sct[0:len(sct) - 1] for sct in shortcuts_list if sct != "ООО "]
    values = []
    for elem in shortcuts_list:
        print(elem)
        if elem != "ООО ":
            values.append(get_shortcuts(str(elem), sparql_param))
    d = dict(zip(keys, values))
    d.update({"TOTAL": sum(values)})
    return d


def get_firms_by_region(region_code_param, sparql_param):
    """
    :param      region_code_param:  Code of the region <String>

    :param      sparql_param:       SPARQL endpoint

    :return:    amount of firms in region with a number of region_code_param
    """
    sparql_param.setQuery(QUERY_GET_FIRM_BY_REGION.format(rg_cd=region_code_param))
    sparql_param.setReturnFormat(JSON)
    results = sparql_param.query().convert()
    return len(results["results"]["bindings"])


def get_region_codes(sparql_param):
    """
    :param      sparql_param:            SPARQL endpoint

    :return:    return_list<String>:     List of unique region codes
    """
    sparql_param.setQuery(QUERY_GET_REGION_CODES)
    sparql_param.setReturnFormat(JSON)
    results = sparql_param.query().convert()
    return_list = list()
    for res in results["results"]["bindings"]:
        return_list.append(res["region_code"]["value"])
    return_list = list(set(return_list))
    return return_list


def get_firm_stats_by_region(sparql_param, full=False):
    """
    :param      sparql_param:   SPARQL endpoint

    :param      full:           Flag which indicates if we need to include 77 and 50 regions in return lists

    :return:    (list_of_region_codes<String>, amount_of_firms_by_region<Integer>)
    """
    list_of_region_codes = get_region_codes(sparql_param)
    if not full:
        # Don't take regions with 77 and 50 code.
        amount_of_firms_by_region = [get_firms_by_region(rc, sparql_param) for rc in list_of_region_codes if
                                     rc != "77" and rc != "50"]
        fixed_list_of_region_codes = [r for r in list_of_region_codes if r != "77" and r != "50"]
        return fixed_list_of_region_codes, amount_of_firms_by_region
    else:
        amount_of_firms_by_region = [get_firms_by_region(rc, sparql_param) for rc in list_of_region_codes]
        return list_of_region_codes, amount_of_firms_by_region


@timer
def get_shortcuts(srt_param, sparql_param):
    """
    :param      srt_param:      shortcut of form (OAO, OOO, etc.)

    :param      sparql_param:   SPARQL endpoint

    :return:    return_list:    list of dictionaries {shortName: %name%}

    Executed in 4 - 40 seconds.
    """
    sparql_param.setQuery(QUERY_GET_SHORTCUTS_AMOUNT.format(sct=srt_param))
    sparql_param.setReturnFormat(JSON)
    return sparql_param.query().convert()["results"]["bindings"][0]['namecount']['value']


def get_ooo_count(sparql_param):
    sparql_param.setQuery(QUERY_TEST_FORMS.format(sct="ООО "))
    sparql_param.setReturnFormat(JSON)
    results = sparql_param.query().convert()
    return_list = list()
    for res in results["results"]["bindings"]:
        return_list.append(sp._responseToDict(res))
    return return_list
