import igraph
import pandas as pd
import itertools
from matplotlib import pyplot as plt

# Достаем сеть
QQ = """
PREFIX foaf: <http://xmlns.com/foaf/0.1/>
PREFIX fts: <https://w3id.org/datafabric.cc/ontologies/fts#>
SELECT DISTINCT ?ogrn ?name{{

?le a fts:C9_Legal_Entity.
?le fts:p28_le_primary_state_registration_number ?ogrn.
      
 ?addrE a fts:C39_Address_Entity;
           fts:p82_refers_to_company ?le;
      	  fts:p98_located_at ?region_code.
 ?region_code fts:p19_region_code ?rg.
 
  BIND("50" AS ?rg)
              
  ?fe a fts:C54_Founder_Entity;
             fts:p82_refers_to_company ?le.
  
  ?fe fts:p101_relates_to_person ?person.
   ?person foaf:name ?name.
}}
"""

def ttt(sparql):
    sparql.setQuery(QQ)
    sparql.setReturnFormat(JSON)
    results = sparql.query().convert()
    returnList = list()
    for res in results["results"]["bindings"]:
        returnList.append(sp._responseToDict(res))
    return returnList

# Формируем, визуализируем и пишем в файл
t = st.ttt(sparql)
print(t)
spisok_cortegey = [(r['ogrn'], r['name']) for r in t]
print(spisok_cortegey)
f = open("Cortegeys.txt", 'w')
f.write(spisok_cortegey.__str__())
f=open("Cortegeys.txt", 'r')
cortegey = eval(f.read())
print(cortegey)
le, fe = zip(*cortegey)
le = list(itertools.zip_longest(set(le), [], fillvalue=True))
fe = list(itertools.zip_longest(set(fe), [], fillvalue=False))
print(le)
le.extend(fe)
verteces = [(i, *item) for i, item in enumerate(le)]
verteces = pd.DataFrame(verteces, columns=["id", "name", "type"])
edges = pd.DataFrame(cortegey, columns=["src", "trg"])
edges = edges.merge(verteces, how="left", left_on="src", right_on="name")\
                .merge(verteces, how="left", left_on="trg", right_on="name")
graph = igraph.Graph.Bipartite(verteces["type"], edges[["id_x", "id_y"]].itertuples(name=None, index=False))
igraph.plot(graph, "graph.pdf",
            bbox=(10000, 10000),
            layout=graph.layout("circle"),
            vertex_color=["red" if i else "blue" for i in graph.vs["type"]],
            vertex_size=100,
            edges_width=1
            )


# Концепт поиска сообществ
"""
# fastgreedy
method_name = "fastgreedy"
res = graph.community_fastgreedy()
clst = res.as_clustering(res.optimal_count)
graph.vs[method_name] = [0]
tmp = {}
for c, sg in enumerate(clst.subgraphs()):
    for vname in sg.vs["name"]:
        tmp.update({vname: c})

for i in graph.vs:
    i[method_name] = tmp[i["name"]]
# код для отрисовки

def igraphGetVertexByName(g, name):
    for v in g.vs:
        if v["name"] == name:
            return v.index


palette = igraph.ClusterColoringPalette(len(set(graph.vs[method_name])))
groups = [(list(map(lambda x: igraphGetVertexByName(g, x), sg.vs["name"])), palette[c])
          for c, sg in enumerate(clst.subgraphs())]
graph.vs["label"] = list(map(lambda x: "ver-" + str(x), graph.vs["name"]))
graph.vs["label"] = ["A", "B", "C"]
igraph.plot(graph,  # "graph.png",
            layout=graph.layout("auto"),
            mark_groups=groups,
            vertex_size=10,
            # vertex_color=[palette.get(t) for i in graph.vs[method_name]],
            vertex_label=graph.vs["name"],
            vertex_label_dist=-3
            )
plt.show()
"""